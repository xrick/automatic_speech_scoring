---
slug: ui-should-not-be-the-bottleneck
title: UI Should Not Be The Bottleneck
authors: [tim]
tags: [release, v0.3.3]
---

WIP

<!--truncate-->
