---
sidebar_position: 7
title: "❓ FAQ"
---

# FAQ

**What's the difference between Functions and Pipelines?**

The main difference between Functions and Pipelines is that Functions are executed directly on the Open WebUI server, while Pipelines are executed on a separate server, potentially reducing the load on your Open WebUI instance.
