export default {
	presets: ["@docusaurus/core/lib/babel/preset"],
};
