﻿namespace SpeechScore
{
    using System.Windows;

    /// <summary>
    /// App.xaml interactive logic
    /// </summary>
    public partial class App : Application
    {
    }
}
